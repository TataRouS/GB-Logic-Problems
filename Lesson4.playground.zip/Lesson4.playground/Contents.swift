import UIKit

//Решите задачу:
//Дан связный список. Напишите функцию, которая бы находила в нем зацикливание, если цикл есть, функция должна вернуть true, в обратном случае — false.
//Структура элемента списка:
//final class Node {
//let value: Int
//var next: Node?
//init(value: Int) {
//self.value = value
//}
//}


final class Node {
    let value: Int
    var next: Node?
    init(value: Int) {
        self.value = value
    }
    
    static func isCyclePresent(first: Node) -> Bool {
        //массив пройденных элементов списка
        var nodeArray: [Node?] = []
        // "указатель" на следующий элемент связанного списка
        var nextElem = first.next
        // цикл пока не пройдем до конца списка (концом считаем, когда nextElem == nil)
        while (nextElem != nil) {
            if (nodeArray.contains(where: {$0?.value == nextElem?.value})){
                // если элемент содержится в массиве пройденных элементов, значит этот элемент уже проходили ранее,
                // значит есть цикл
                return true
            }
            //добавляем обработанный элемент в массив пройденных
            nodeArray.append(nextElem)
            nextElem = nextElem?.next
        }
        //если дошли до последнего элемента значит цикла нет
        return false
    }
}

Node.isCyclePresent(first: Node(value: 0))
